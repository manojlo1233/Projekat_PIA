import { Lokacija } from "./lokacija"

export class Sto{
    x_poz: number;
    y_poz: number;
    x_duzina: number;
    y_duzina: number;
    krug: boolean;
    id: number;
}