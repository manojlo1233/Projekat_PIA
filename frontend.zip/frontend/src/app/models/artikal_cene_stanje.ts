export class Artikal_cene_stanje{
    sifra: number;
    nabavna_cena: number;
    prodajna_cena: number;
    stanje_lagera: number;
    min_kolicina: number;
    max_kolicina: number;
}