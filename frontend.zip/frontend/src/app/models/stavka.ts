export class Stavka{
    sifra: number;
    kolicina: number;
    porez: number;
    cena: number;
}