export class Sifra_promena{
    broj: number;
    nov_broj: number;
}