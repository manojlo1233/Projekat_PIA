export class Banka{
    id: number;
    naziv: string;
}