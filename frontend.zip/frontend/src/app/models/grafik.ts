export class Grafik{
    name: string;
    value: number;
}