export class Adresa{
    drzava: string;
    grad: string;
    postanski_broj: string;
    ulica_broj: string;
}