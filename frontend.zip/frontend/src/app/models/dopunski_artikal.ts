export class Dopunski_artikal{
    zemlja_porekla: string;
    strani_naziv: string;
    barkod: number;
    proizvodjac: string;
    carinska_tarifa: string;
    eko_taksa: boolean;
    akcize: boolean;
    min_zaliheP: number;
    max_zaliheP: number;
    opis: string;
    deklaracija: string;
}