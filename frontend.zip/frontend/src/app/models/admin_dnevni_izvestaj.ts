export class Admin_izvestaj{
    preduzece: string;
    pib: number;
    dnevni_pazar: number;
    pdv: number;
    dan: string;
}