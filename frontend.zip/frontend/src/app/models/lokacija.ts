export class Lokacija{
    drzava: string;
    grad: string;
    ulicaBroj: string;
    
}