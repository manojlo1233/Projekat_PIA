import { Sifra } from "./sifra";

export class Potkategorija{
    potkategorija: string;
    artikli: Array<Sifra>
}