export class Sifra{
    broj: number
}