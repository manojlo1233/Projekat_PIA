export class Ziro_racun{
    broj: string;
    banka: string;
}