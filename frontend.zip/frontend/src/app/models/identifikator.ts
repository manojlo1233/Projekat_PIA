export class IDMagacina{
    identifikator: string;
}