export class Narucilac{
    broj_dana_placanja: number;
    procenat_rabata: number;
    narucilac: string
}