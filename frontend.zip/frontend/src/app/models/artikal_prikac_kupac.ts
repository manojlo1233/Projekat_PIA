export class Artikal_prikaz_kupac{
    naziv: string;
    cena: number;
    proizvodjac: string;
}