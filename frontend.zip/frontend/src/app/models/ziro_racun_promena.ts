export class Ziro_racun_promena{
    broj: string;
    banka: string;
    nov_broj: string;
    nova_banka:string;
}