export class Kupac{
    kor_ime: string;
    lozinka: string;
    ime: string;
    prezime: string;
    telefon: number;
    broj_licne: number;
    tip: string;
}