import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Kupac } from '../models/kupac';
import { Preduzece } from '../models/preduzece';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-promena-lozinke-login',
  templateUrl: './promena-lozinke-login.component.html',
  styleUrls: ['./promena-lozinke-login.component.css']
})
export class PromenaLozinkeLoginComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
  }

  kor_ime: string
  nova_lozinka: string = ''
  potvrda_nove: string = ''
  tip_korisnika = 'kupac'
  licna_karta: number = 0;
  mail: string

  promeni_lozinku(){

    if ( this.tip_korisnika === 'kupac' && this.licna_karta <= 0){
      this.snackBar.open("Унети личну карту купца", "Затвори")
      return
    }
    if ( this.tip_korisnika === 'preduzece' && this.mail === ''){
      this.snackBar.open("Унети мејл адресу предузећа", "Затвори")
      return
    }
    
    if ( this.tip_korisnika === 'kupac'){
      this.userService.proveriKupca(this.kor_ime, this.licna_karta).subscribe((data: Kupac)=>{
        if (data['message'] === 'korisnik pronadjen'){
          this.userService.promeniLozinku(this.kor_ime, this.nova_lozinka).subscribe((resp)=>{
            if ( resp['message'] === "ok") {
               this.snackBar.open("Успешно промењена лозинка", "Затвори")
               sessionStorage.clear();
               this.router.navigate([""]);
            }
            else{
              this.snackBar.open("Лозинка није промењена")
            }
          });
        }
        else{
          this.snackBar.open("Корисник није пронађен", "Затвори")
          return
        }
      })
    }
    else if (this.tip_korisnika === 'preduzece'){
      this.userService.proveriPreduzece(this.kor_ime, this.mail).subscribe((data: Preduzece)=>{
        if (data['message'] === 'korisnik pronadjen'){
          this.userService.promeniLozinku(this.kor_ime, this.nova_lozinka).subscribe((resp)=>{
            if ( resp['message'] === "ok") {
               this.snackBar.open("Успешно промењена лозинка", "Затвори")
               sessionStorage.clear();
               this.router.navigate([""]);
            }
            else{
              this.snackBar.open("Лозинка није промењена")
            }
          });
        }
        else{
          this.snackBar.open("Корисник није пронађен", "Затвори")
          return
        }
      })
    }
  }

  potvrdi_novu_lozniku(){
    if ( this.potvrda_nove === this.nova_lozinka) return true;
    else return false;
  }


  logout(){
    sessionStorage.clear();
    this.router.navigate(['']);
  }

}
