import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PromenaLozinkeLoginComponent } from './promena-lozinke-login.component';

describe('PromenaLozinkeLoginComponent', () => {
  let component: PromenaLozinkeLoginComponent;
  let fixture: ComponentFixture<PromenaLozinkeLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PromenaLozinkeLoginComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PromenaLozinkeLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
